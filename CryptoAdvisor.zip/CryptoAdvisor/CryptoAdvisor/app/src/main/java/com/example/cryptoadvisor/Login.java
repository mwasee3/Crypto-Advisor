package com.example.cryptoadvisor;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    EditText Email,Password;
    Button login;
    TextView Register;
    FirebaseAuth authF;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Email=findViewById(R.id.Email);
        Password=findViewById(R.id.editTextTextPassword);
        login=findViewById(R.id.Button_login);
        Register=findViewById(R.id.have_account);
        authF=FirebaseAuth.getInstance();
//        if(authF.getCurrentUser()!=null){
//            startActivity(new Intent(getApplicationContext(),MainActivity.class));
//        }
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email=Email.getText().toString().trim();
                String pass=Password.getText().toString().trim();
                if(TextUtils.isEmpty(email)){
                    Email.setError("Email not entered");
                    return;
                }
                if(TextUtils.isEmpty(pass)){
                    Password.setError("password needed");
                    return;
                }
                if(pass.length()<8){
                    Password.setError("password small");
                    return;
                }
                authF.signInWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Login.this,"User Logged in", Toast.LENGTH_SHORT);
                            startActivity(new Intent(getApplicationContext(),HomePage.class));
                        }
                        else{
                            Toast.makeText(Login.this,task.getException().getMessage(), Toast.LENGTH_SHORT);
                        }
                    }
                });
            }
        });
        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Register.class));
            }
        });
    }
}