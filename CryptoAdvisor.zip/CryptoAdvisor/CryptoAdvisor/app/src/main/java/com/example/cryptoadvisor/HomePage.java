package com.example.cryptoadvisor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class HomePage extends AppCompatActivity {
    Button signout;
    Button man_pref;
    TextView tv;
    Button forum;
    private RequestQueue mQueue;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        signout=findViewById(R.id.signout);
        tv=findViewById(R.id.tv1);
        mQueue= Volley.newRequestQueue(this);
        signout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        });
        jsonParse();
        man_pref=findViewById(R.id.man_pref);
        man_pref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Preference.class));
                finish();
            }
        });
        forum = findViewById(R.id.forum);
        forum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),MainActivity2.class));
                finish();
            }
        });
    }
    private void jsonParse(){
        String url="https://yh-finance.p.rapidapi.com/stock/v2/get-recommendations?symbol=INTC";
        JsonObjectRequest request= new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
//                try {
//                    JSONArray jsonArray= response.getJSONArray("finance");
////                    JSONArray jsonArra=jsonArray.getJSONArray(0);
//                    JSONObject result=jsonArray.getJSONObject(0);
//                    int marketPrice= result.getInt("count");


                tv.setText(response.toString());

//                } catch (JSONException e) {
//                    e.printStackTrace();
//                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                tv.setText("" +error.toString());
            }


        }){
            @Override
            public Map<String,String> getHeaders() throws AuthFailureError {
                Map<String,String> params= new HashMap<>();
                params.put("x-rapidapi-host", "yh-finance.p.rapidapi.com");
                params.put("x-rapidapi-key", "ca7a15a1d0msh8a2cb485139496cp11411djsn443a03c3c412");
                return params;
            }
        };
        mQueue.add(request);
    }

}