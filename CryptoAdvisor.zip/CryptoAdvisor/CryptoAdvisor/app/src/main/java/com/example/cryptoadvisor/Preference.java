package com.example.cryptoadvisor;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;


public class Preference extends AppCompatActivity {
    DatabaseHelper peopleDB;
    String pref = "empty";
    ArrayList<String> pref_List = new ArrayList<String>(3);
    int counter = 0;
    int counter_1 = 0;
    String email;
    FirebaseAuth authF;
    FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
    String userEmail = user.getEmail();
    private DocumentReference mDocRef = FirebaseFirestore.getInstance().document("sampleData/" + userEmail);

    protected Button b_01;
    protected Button b_02;
    protected Button b_03;

    protected Button b0 ;
    protected Button b1 ;
    protected Button b2 ;
    protected Button b3 ;
    protected Button b4 ;
    protected Button b5 ;
    protected Button b6 ;
    protected Button b7 ;
    protected Button b8 ;
    protected Button b9 ;



    protected TextView t1;
    public static final String EMAIL_KEY = "email";
    public static final String PREFERENCE_TYPE_KEY = "pref_type";
    public static final String PREFERENCE1_KEY = "pref1";
    public static final String PREFERENCE2_KEY = "pref2";
    public static final String PREFERENCE3_KEY = "pref3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preference);
        b_01 = findViewById(R.id.button);
        b_02 = (Button) findViewById(R.id.button2);
        b_03 = (Button) findViewById(R.id.button3);
        b0 = (Button) findViewById(R.id.prefrence0);
        b1 = (Button) findViewById(R.id.prefrence1);
        b2 = (Button) findViewById(R.id.prefrence2);
        b3 = (Button) findViewById(R.id.prefrence3);
        b4 = (Button) findViewById(R.id.prefrence4);
        b5 = (Button) findViewById(R.id.prefrence5);
        b6 = (Button) findViewById(R.id.prefrence6);
        b7 = (Button) findViewById(R.id.prefrence7);
        b8 = (Button) findViewById(R.id.prefrence8);
        b9 = (Button) findViewById(R.id.prefrence9);


        b_01.setOnClickListener(b_01Listener) ;
        b_02.setOnClickListener(b_02Listener) ;
        b_03.setOnClickListener(doneListener) ;
        b0.setOnClickListener(b0Listener) ;
        b1.setOnClickListener(b1Listener) ;
        b2.setOnClickListener(b2Listener) ;
        b3.setOnClickListener(b3Listener) ;
        b4.setOnClickListener(b4Listener) ;
        b5.setOnClickListener(b5Listener) ;
        b6.setOnClickListener(b6Listener) ;
        b7.setOnClickListener(b7Listener) ;
        b8.setOnClickListener(b8Listener) ;
        b9.setOnClickListener(b9Listener) ;


    }




    public View.OnClickListener b_01Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (pref == "Day Trade") {
                b_02.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                counter_1 = 0;
            }
            if (counter_1 == 0 || pref == "Long Term") {

                pref = "Long Term";
                b_01.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                counter_1 = 1;
            }
        }
    };

    public View.OnClickListener b_02Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (pref == "Long Term") {
                b_01.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
                counter_1 = 0;
            }
            if (counter_1 == 0 || pref == "Day Trade") {

                pref = "Day Trade";
                b_02.setBackgroundTintList(ColorStateList.valueOf(Color.RED));
                counter_1 = 1;
            }
        }
    };

    public View.OnClickListener doneListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (pref == "" || pref_List.get(0) == "" || pref_List.get(1) == "" || pref_List.get(2) == "") {
            }
            else {

                Map<String, Object> dataToSave = new HashMap<String, Object>();
//                String userEmail = user.getEmail();
                dataToSave.put(EMAIL_KEY, userEmail);
                dataToSave.put(PREFERENCE_TYPE_KEY, pref);
                dataToSave.put(PREFERENCE1_KEY, pref_List.get(0));
                dataToSave.put(PREFERENCE2_KEY, pref_List.get(1));
                dataToSave.put(PREFERENCE3_KEY, pref_List.get(2));
                mDocRef.set(dataToSave).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        Log.d("Tag", "Preferences Saved");
                    }
                });

                startActivity(new Intent(getApplicationContext(),HomePage.class));
            }

        }
    };

    public View.OnClickListener b0Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            if (counter < 3) {
                pref_List.add("Energy");
                counter = counter+1;
                b0.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
    public View.OnClickListener b1Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("Materials");
                counter = counter+1;
                b1.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
    public View.OnClickListener b2Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("Industrials");
                counter = counter+1;
                b2.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
    public View.OnClickListener b3Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("Consumer Discretionary");
                counter = counter+1;
                b3.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
    public View.OnClickListener b4Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("Consumer Staples");
                counter = counter+1;
                b4.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
    public View.OnClickListener b5Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("Health Care");
                counter = counter+1;
                b5.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
    public View.OnClickListener b6Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("Financials");
                counter = counter+1;
                b6.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
    public View.OnClickListener b7Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("IT");
                counter = counter+1;
                b7.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };public View.OnClickListener b8Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (counter < 3) {
                pref_List.add("Communication Services");
                counter = counter+1;
                b8.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };public View.OnClickListener b9Listener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            if (counter < 3) {
                pref_List.add("Utilities");
                counter = counter+1;
                b9.setBackgroundTintList(ColorStateList.valueOf(Color.GREEN));
            }
        }
    };
}